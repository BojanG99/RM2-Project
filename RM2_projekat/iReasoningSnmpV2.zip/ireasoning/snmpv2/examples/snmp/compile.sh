#!/bin/sh
javac -classpath ../../lib/ireasoningsnmp.jar *.java
